******************
*** OpenSolver ***
******************

http://www.opensolver.org

OpenSolver is an Excel add-in that extends Excel�s built-in Solver with a more powerful Linear Programming solver. OpenSolver provides the following features:

�OpenSolver uses the excellent, Open Source, COIN-OR CBC optimization engine, to quickly solve large Linear and Integer problems.
�Compatible with your existing Solver models, so there is no need to change your spreadsheets
�No artificial limits on the size of problem you can solve
�OpenSolver is free, open source software licensed under the GPL.
�Note that OpenSolver does not solve non-linear optimization problems, so your Solver model needs to have �Assume Linear Model� turned on. 

As well as providing a replacement optimization engine, OpenSolver offers:

�A built-in model visualizer that highlights your model�s decision variables, objective and constraints directly on your spreadsheet
�A fast QuickSolve mode that makes it much faster to re-solve your model after making changes to a right hand side
*An optional model building tool that analyses your spreadsheet, and then fills in the Solver dialog automatically

OpenSolver has been developed for Excel 2007 and 2010 running on Windows. It should work with these or later Excel versions.

You can Download OpenSolver from SourceForge; see http://www.opensolver.org

OpenSolver is being developed by Andrew Mason in the Department of Engineering Science at the University of Auckland. 

OpenSolver uses the open source COIN-OR CBC optimization engine. Cbc is released as open source code under the  Common Public License (CPL). It is available from the  COIN-OR initiative. The CBC code has been written by primarily by John J. Forrest, and is maintained by Ted Ralphs.

Please see the included license files for more details.

Note: OpenSolver used to require Assume Non-Negative to be turned on; this is no longer the case. See the ChangeLog file for more details of recent improvements.


Installation
************

1/ Download the OpenSolver.zip file from www.opensolver.org
2/ Extract the files to a convenient location
3/ Double click on OpenSolver.xlam
4/ If asked, give Excel permissions to run OpenSolver

The OpenSolver commands will then appear under Excel�s Data tab.

OpenSolver will be available until you quit Excel. If you wish to make OpenSolver always available in Excel, the files from the .zip all need to be copied into the Excel add-in directory. This is typically: C:\Documents and Settings\�user name�\Application Data\Microsoft\Addins\

Using OpenSolver
****************

The OpenSolver commands appear under Excel�s Data tab.

OpenSolver works with your existing Solver models. It does not replace Solver which you can still use to build your models. However, if you prefer, you can use OpenSolver's AutoModel feature which will attempt to enter all the data into Solver automatically. It does this by looking for an objective function in a row containing the word 'min' or 'max' (or similar). It then looks for cells containing <=, = and >= that define constraints.

Once you have built your model, you should check it using OpenSolver�s �Show/Hide Model� button.

To solve the model, first turn on the �Assume Linear Model� option, or choose the Simplex engine. Then click OpenSolver�s Solve button. OpenSolver then analyses your spreadsheet to extract the optimization model, which is then written to a file and passed to the CBC optimization engine to solve. The result is then read in, and automatically loaded back into your spreadsheet. A dialog is shown only if errors occur.

After solving, OpenSolver does a quick check that your model is a linear one in the sense that the objective and constraints behave as expected when the optimal solution is loaded into the sheet. If it is not, OpenSolver shows an alert, and can then do a detailed linearity analysis.

The Solver tolerance and maximum time options are respected by OpenSolver. If you turn on Solver�s �Show Iteration Results�, OpenSolver will briefly display the CBC output during the solution process (which is typically very fast).

Please visit http://www.opensolver.org for more information.

